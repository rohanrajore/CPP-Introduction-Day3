#include <iostream>
#include <string>
using namespace std;

struct Person {
    string name = "Unknown";  // default value
    int age;              // default value
};

int main() {

    Person p1;                 // no initialization
    Person p2 = {"Alice", 25}; // full initialization
    Person p3 = {"Bob"};       // partial initialization
    Person p4 = {};          // empty initialization    

    cout << "p1: " << p1.name << ", " << p1.age << endl;
    cout << "p2: " << p2.name << ", " << p2.age << endl;
    cout << "p3: " << p3.name << ", " << p3.age << endl;
    cout << "p4: " << p4.name << ", " << p4.age << endl;

    return 0;
}

//  Default member values
//  No garbage values
//  Full initialization
//  Partial initialization
//  Order matters
//  string + int together
//  How defaults are used only when needed