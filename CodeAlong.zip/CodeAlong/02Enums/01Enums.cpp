#include <iostream>
using namespace std;

/*
----------------------------------------------------
ENUMS IN C++ – COMPLETE CONCEPT DEMO
----------------------------------------------------

This file demonstrates:
1. What an enum is
2. Default enum values
3. Custom enum values
4. Enum auto-increment behavior
5. Assigning enum to variables
6. Printing enum values
7. Invalid enum values (important!)
8. enum vs enum class (basic idea)
----------------------------------------------------
*/

// 1️⃣ Basic enum
enum Status {
    Ok,        // 0
    Error,     // 1
    Warning    // 2
};

// 2️⃣ Enum with custom values
enum Level {
    Low = 10,
    Medium,    // 11
    High = 20
};

int main() {

    cout << "----- BASIC ENUM -----\n";
    Status s1 = Ok;
    Status s2 = Warning;

    cout << "Ok value: " << s1 << endl;
    cout << "Warning value: " << s2 << endl;

    cout << "\n----- CUSTOM VALUES -----\n";
    Level l1 = Low;
    Level l2 = Medium;
    Level l3 = High;

    cout << "Low: " << l1 << endl;
    cout << "Medium: " << l2 << endl;
    cout << "High: " << l3 << endl;

    cout << "\n----- ENUM AS INTEGER -----\n";
    int x = Error;   // enum → int (allowed)
    cout << "Error as int: " << x << endl;

    cout << "\n----- INVALID ENUM VALUE -----\n";
    Status s3 = (Status)999;  // forced assignment
    cout << "Invalid enum value stored: " << s3 << endl;

    cout << "\n----- ENUM COMPARISON -----\n";
    if (s1 == Ok) {
        cout << "Status is OK\n";
    }

    cout << "\n----- ENUM IN CONDITIONS -----\n";
    if (l3 > l1) {
        cout << "High is greater than Low\n";
    }

    cout << "\n----- ENUM vs ENUM CLASS -----\n";
    cout << "enum: allows implicit int conversion\n";
    cout << "enum class: does NOT allow implicit int conversion\n";

    return 0;
}
