#include <iostream>
using namespace std;

/*
----------------------------------------------------
PREVENTING INVALID ENUM VALUES
----------------------------------------------------

This file demonstrates:
1. How invalid enum values happen
2. Manual validation using if / switch
3. Using enum class for stronger safety
----------------------------------------------------
*/

// 1️⃣ Normal enum (weakly typed)
enum Status {
    Ok = 0,
    Error = 1,
    Warning = 2
};

// Helper variable to define valid range (simple technique)
const int STATUS_MIN = Ok;
const int STATUS_MAX = Warning;

int main() {

    cout << "----- PROBLEM: INVALID ENUM VALUE -----\n";

    Status s1 = (Status)999;   // Forced, invalid value
    cout << "s1 = " << s1 << "  (invalid, but allowed)\n";

    // --------------------------------------------------

    cout << "\n----- SOLUTION 1: MANUAL RANGE CHECK -----\n";

    int rawValue = 999;

    if (rawValue >= STATUS_MIN && rawValue <= STATUS_MAX) {
        Status s2 = (Status)rawValue;
        cout << "Valid Status: " << s2 << endl;
    } else {
        cout << "Invalid Status value rejected\n";
    }

    // --------------------------------------------------

    cout << "\n----- SOLUTION 2: SWITCH VALIDATION -----\n";

    Status s3 = (Status)rawValue;

    switch (s3) {
        case Ok:
        case Error:
        case Warning:
            cout << "Valid Status: " << s3 << endl;
            break;
        default:
            cout << "Invalid Status detected\n";
    }

    // --------------------------------------------------

    cout << "\n----- SOLUTION 3: enum class (STRONGER TYPE) -----\n";

    enum class SafeStatus {
        Ok,
        Error,
        Warning
    };

    SafeStatus ss1 = SafeStatus::Ok;
    cout << "SafeStatus OK assigned successfully\n";

    // ❌ The following line would NOT compile:
    // SafeStatus ss2 = 999;

    // Still possible with explicit cast (must be intentional)
    SafeStatus ss3 = static_cast<SafeStatus>(999);

    cout << "Forced invalid SafeStatus assigned (not recommended)\n";

    // Validate SafeStatus
    switch (ss3) {
        case SafeStatus::Ok:
        case SafeStatus::Error:
        case SafeStatus::Warning:
            cout << "Valid SafeStatus\n";
            break;
        default:
            cout << "Invalid SafeStatus detected\n";
    }

    return 0;
}
