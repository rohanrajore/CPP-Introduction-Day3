#include <iostream>
using namespace std;

// ---------- FUNCTION DECLARATIONS ----------
int add(int a, int b);            // overload 1
double add(double a, double b);   // overload 2
int square(int x);                // returns a value

int main() {

    // ---------- CALLING FUNCTIONS ----------
    int sum1 = add(10, 20);          // calls int version
    double sum2 = add(5.5, 4.5);     // calls double version
    int sq = square(6);

    cout << "Integer sum: " << sum1 << endl;
    cout << "Double sum: " << sum2 << endl;
    cout << "Square: " << sq << endl;

    return 0;
}

// ---------- FUNCTION DEFINITIONS ----------

// ---------- FUNCTION OVERLOADING ----------
int add(int a, int b) {
    return a + b;   // RETURNING VALUE
}

double add(double a, double b) {
    return a + b;   // RETURNING VALUE
}

// ---------- FUNCTION RETURN ----------
int square(int x) {
    return x * x;
}
