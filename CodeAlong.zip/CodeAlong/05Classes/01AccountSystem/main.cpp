#include <iostream>
#include "Account.h"

int main() {
    Account acc(500);
    acc.deposit(200);
    acc.withdraw(100);
    std::cout << "Balance: " << acc.getBalance() << std::endl;
}
