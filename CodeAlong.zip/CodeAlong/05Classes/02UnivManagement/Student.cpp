#include "Student.h"

Student::Student(int id) : id(id) {}

int Student::getId() const {
    return id;
}
