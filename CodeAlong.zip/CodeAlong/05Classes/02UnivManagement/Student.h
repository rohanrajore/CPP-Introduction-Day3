class Student {
private:
    int id;

public:
    Student(int id);
    int getId() const;
};

