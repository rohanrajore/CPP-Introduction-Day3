#include <iostream>
#include "Student.h"

int main() {
    Student s1(101);
    std::cout << "Student ID: " << s1.getId() << std::endl;
}
