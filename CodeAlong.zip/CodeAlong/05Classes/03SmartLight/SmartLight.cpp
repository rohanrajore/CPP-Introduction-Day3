#include "SmartLight.h"
#include <iostream>

using namespace std;

SmartLight::SmartLight() {
    is_on = false;
    brightness = 0;
    color = "White";
}

void SmartLight::turn_on() {
    is_on = true;
}

void SmartLight::turn_off() {
    is_on = false;
    brightness = 0;
}

void SmartLight::set_brightness(int b) {
    if (b >= 0 && b <= 100) {
        brightness = b;
    }
}

void SmartLight::set_color(const string& c) {
    color = c;
}

void SmartLight::display_status() const {
    cout << "Light: " << (is_on ? "ON" : "OFF") << endl;
    cout << "Brightness: " << brightness << endl;
    cout << "Color: " << color << endl;
}
