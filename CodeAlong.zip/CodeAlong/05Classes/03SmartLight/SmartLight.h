#pragma once
#include <string>

class SmartLight {
private:
    bool is_on;
    int brightness;
    std::string color;

public:
    SmartLight();                 // constructor

    void turn_on();
    void turn_off();
    void set_brightness(int b);
    void set_color(const std::string& c);
    void display_status() const;
};
