#include <iostream>
#include "SmartLight.h"

using namespace std;

int main() {
    SmartLight light;

    light.turn_on();
    light.set_brightness(75);
    light.set_color("Warm White");

    light.display_status();

    return 0;
}
