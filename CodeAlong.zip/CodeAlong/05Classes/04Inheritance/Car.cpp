#include "Car.h"
using namespace std;

Car::Car() {
    fuel_level = 100;
}

void Car::refuel() {
    fuel_level = 100;
}

void Car::display_status() const {
    Vehicle::display_status();
    cout << "Fuel level: " << fuel_level << "%" << endl;
}
