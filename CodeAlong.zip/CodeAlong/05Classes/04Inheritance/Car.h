#pragma once
#include "Vehicle.h"

class Car : public Vehicle {
private:
    int fuel_level;

public:
    Car();

    void refuel();
    void display_status() const;
};
