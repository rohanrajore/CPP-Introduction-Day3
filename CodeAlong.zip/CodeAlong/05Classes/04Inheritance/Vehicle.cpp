#include "Vehicle.h"
using namespace std;

Vehicle::Vehicle() {
    speed = 0;
    engine_on = false;
}

void Vehicle::start_engine() {
    engine_on = true;
}

void Vehicle::stop_engine() {
    engine_on = false;
    speed = 0;
}

void Vehicle::set_speed(int s) {
    if (engine_on && s >= 0) {
        speed = s;
    }
}

int Vehicle::get_speed() const {
    return speed;
}

void Vehicle::display_status() const {
    cout << "Engine: " << (engine_on ? "ON" : "OFF") << endl;
    cout << "Speed: " << speed << endl;
}
