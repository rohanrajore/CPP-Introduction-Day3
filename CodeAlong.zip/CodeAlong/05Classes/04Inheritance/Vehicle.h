#pragma once
#include <iostream>

class Vehicle {
protected:
    int speed;

private:
    bool engine_on;

public:
    Vehicle();

    void start_engine();
    void stop_engine();
    void set_speed(int s);
    int get_speed() const;
    void display_status() const;
};
