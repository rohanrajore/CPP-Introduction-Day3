#include "Car.h"

int main() {
    Car myCar;

    myCar.start_engine();
    myCar.set_speed(60);
    myCar.display_status();

    myCar.refuel();
    myCar.display_status();

    return 0;
}
