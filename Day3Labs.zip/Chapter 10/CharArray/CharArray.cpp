#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	char hello[] = {'H','e','l','l','o','\0'};
	char greeting[] = "Hello World";
	char name[20];
	char fullname[100];

	cout << greeting << endl;
	cout << "Enter your forename: ";
	cin >> name;
	cin.ignore();
	cout << hello << " " << name 
		<< " Enter your full name: ";
	cin.getline(fullname,100);
	cout << hello << " " << fullname << endl;
	
	return 0;
} 
