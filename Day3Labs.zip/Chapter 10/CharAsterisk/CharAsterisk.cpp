#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	char* astring = "Hello World";
	char* bstring;

	bstring = "Hello Universe";

	cout << astring << endl;
	cout << bstring << endl;
	
	return 0;
}
