#include <iostream>
using namespace std;

int main(int argc, char**argv)
{
	char* astring;

	astring = new char[20];

	cin >> astring;

	cout << astring << endl;
	
	return 0;
}
