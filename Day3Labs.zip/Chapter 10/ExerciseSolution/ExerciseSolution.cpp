#include <iostream>
using namespace std;

struct date
{
	int day, month, year;
};

struct person_id
{
	int age;
	char sex;
	float height;
	date* pdob;
};

int main(int argc, char** argv)
{
	person_id* pme = new person_id;
	pme->pdob = new date;

	cout << "How old are you? ";
	cin >> pme->age;
	cout << "Are you Male(M) or Female(F)? ";
	cin >> pme->sex;
	cout << "How tall are you in meters? ";
	cin >> pme->height;
	cout << "Enter your date of birth in the format dd mm yyyy: ";
	cin >> pme->pdob->day >> pme->pdob->month >> pme->pdob->year;

	cout << "You are a " << pme->age << " year old "
		<< ((pme->sex == 'M')?"Male":"Female")
		<< " You are " << pme->height << " meters tall"
		<< " and your DOB is: " << pme->pdob->day << "/"
		<< pme->pdob->month << "/" << pme->pdob->year << endl;

	delete pme->pdob;
	delete pme;
	
	return 0;
}
