//
// pointer declaration
//

#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	int an_integer;
	double a_double;

	int* an_integer_pointer;
	int* another_integer_pointer;

	double* a_double_pointer;
}
