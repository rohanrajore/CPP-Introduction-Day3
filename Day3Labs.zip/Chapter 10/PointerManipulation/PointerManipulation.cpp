// 
// pointers
//

#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	int value = 54377017;
	int* value_ptr = & value;
	
	value = 12345;
	*value_ptr = 67890;
	cout << *value_ptr << endl;
}
