//
// Pointers to structures
//

struct date
{
	int day;
	int month;
	int year;
};

int main(int argc, char** argv)
{
	date birthday = {21,10,1958};
	date* date_ptr = &birthday;

	date_ptr->day = 25;
	date_ptr->month = 12;
	date_ptr->year = 1999;
}
