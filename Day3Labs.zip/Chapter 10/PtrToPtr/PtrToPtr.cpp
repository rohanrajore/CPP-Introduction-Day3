#include <iostream>
using namespace std;

int main(int argc, char** argv)
{ 
	int x;
	int* pint;
	int** ppint;
	int*** pppint;
	
	pint = &x;
	ppint = &pint;
	pppint = &ppint;
	
	x = 10;
	*pint = 20;
	**ppint = 30;
	***pppint = 40;
	
	cout << x << endl;
	cout << *pint << endl;
	cout << **ppint << endl;
	cout << ***pppint << endl;
	
	return 0;
}
