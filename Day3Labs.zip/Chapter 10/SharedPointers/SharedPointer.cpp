#include <iostream>
#include <memory>
using namespace std;

class Person
{
public:
	Person() { cout << "Person Constructor\n"; }
	~Person() { cout << "Person Destructor\n"; }
	void UsePerson() { cout << "Using Person\n"; }
};

void SharedPtr()
{
	std::shared_ptr<Person> p1;								// uninitialised shared_ptr
	cout << "p1 use_count: " << p1.use_count() << '\n';		// p1.use count = 
	std::shared_ptr<Person> p2(nullptr);					// shared_ptr explicitly initialised to nullptr
	cout << "p2 use_count: " << p2.use_count() << '\n';		// p2.use count = 0
	std::shared_ptr<Person> p3(new Person);					// shared_ptr initialised with a person
	cout << "p3 use_count: " << p3.use_count() << '\n';		// p3.use count = 1
	std::shared_ptr<Person> p4(p3);							// shared_ptr as a copy of p3 
	cout << "p3 use_count: " << p3.use_count() << '\n';		// p3.use count = 2
	cout << "p4 use_count: " << p4.use_count() << '\n';		// p4.use count = 2
	p3->UsePerson();										// UsePerson via p3
	p4->UsePerson();										// usePerson via p4
	std::shared_ptr<Person> p5(std::move(p4));				// shared_ptr initialised by moving p4.  
															// p4 no longer owns Person
	cout << "p3 use_count: " << p3.use_count() << '\n';		// p3.use count = 2
	cout << "p4 use_count: " << p4.use_count() << '\n';		// p4.use count = 0
	cout << "p5 use_count: " << p5.use_count() << '\n';		// p5.use count = 2
	p3.reset();												// remove Person from p3
	cout << "p3 use_count: " << p3.use_count() << '\n';		// p3.use count = 0
	cout << "p4 use_count: " << p4.use_count() << '\n';		// p4.use count = 0
	cout << "p5 use_count: " << p5.use_count() << '\n';		// p5.use count = 1
	p5.reset();												// remove Person from p5.  
															// No shared users so Person is destroyed
	cout << "p3 use_count: " << p3.use_count() << '\n';		// p3.use count = 0
	cout << "p4 use_count: " << p4.use_count() << '\n';		// p4.use count = 0
	cout << "p5 use_count: " << p5.use_count() << '\n';		// p5.use count = 0
}

