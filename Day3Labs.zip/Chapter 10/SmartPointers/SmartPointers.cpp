#include <string.h>
#include <memory>
using namespace std;

struct Person
{
	char Name[255];
	int age;
	char sex;
};

void UseRawPointer()
{
	// Using a raw pointer -- not recommended.
	Person* pSimon = new Person;
	// Use pSimon... 
	strcpy(pSimon->Name, "Simon Bailey");
	pSimon->age = 21;
	pSimon->sex = 'M';
	// Don't forget to delete! 
	delete pSimon;
}

void UseSmartPointer()
{
	// Declare a smart pointer on stack and pass it the raw pointer.
	unique_ptr<Person> someone(new Person);
	// Use someone...
	strcpy(someone->Name, "Simon Bailey");
	someone->age = 21;
	someone->sex = 'M';
	//...

} // someone is deleted automatically here.

void SmartPointerDemo2()
{
	// Create the object and pass it to a smart pointer
	std::unique_ptr<Person> someoneElse(new Person);
	// Use someone...
	strcpy(someoneElse->Name, "Simon Bailey");
	someoneElse->age = 21;
	someoneElse->sex = 'M';
	//...

	// Free the memory before we exit function block.
	someoneElse.reset();

	// Do some other work...

}


