// the C strtok() function in C++ code
// In this program, a loop uses strtok() to print all the 
// tokens (separated by blanks)
#include <string.h>
#include <iostream>
using namespace std;

char *astring; 
char separators[] = " ,\t\n*";
char *token, *next_token;

int main(int argc, char** argv)
{
	astring = new char[255];
	strcpy(astring, "A string\tof,tokens\nand*some more,tokens");

	cout << astring << endl;
	cout << "Tokens:" << endl;
	// establish a string and get the first token:
	token = strtok(astring, separators);

	// while there are tokens in "string1" or "string2"
	while (token != NULL)
	{
		// get the next token:
		if (token != NULL)
		{
			cout << token << endl;
			token = strtok(NULL, separators);
		}
	}
	cout << astring << endl;
	return 0;
}
