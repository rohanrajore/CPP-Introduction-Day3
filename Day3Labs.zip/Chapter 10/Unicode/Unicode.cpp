#include <iostream>
#include <locale.h>
#include <time.h>
#include <wchar.h>
using namespace std;

int main(int argc, char** argv)
{
	char* retstr = new char[255];
	// the C locale will be UTF-8 enabled GB English;
    // decimal dot will be French
    // date and time formatting will be German
    retstr = setlocale(LC_ALL, "en_GB.UTF-8");
	cout << retstr << endl;
	retstr = setlocale(LC_NUMERIC, "fr_FR.utf8");
	cout << retstr << endl;
	retstr = setlocale(LC_TIME, "de_DE.utf8");
	cout << retstr << endl;
		
	wstring name = L"Simon Bailey";
	wchar_t ch = L'@';
	wcout << name << ch << endl;
	wcout << L"The wide char value of '@' is " << (int)ch << endl;
	wcout << L"The size of the wide char is " << sizeof(ch) << endl;
	 
    double num = 3.14;
    wcout << L"Number: " << num << endl;
    wchar_t str[100];
    time_t t = time(NULL);
    wcsftime(str, 100, L"%A %c", localtime(&t));
    wcout << L"Date: " << str << endl;
	
	return 0;
} 
