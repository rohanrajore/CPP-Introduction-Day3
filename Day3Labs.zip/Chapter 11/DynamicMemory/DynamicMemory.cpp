#include <iostream>
#include <string.h>
using namespace std;

int main(int argc, char** argv)
{
	int* iptr;
	iptr = new int;
	delete iptr;

	char* msg;
	msg = new char[255];
	strcpy(msg, "Hello world!");
	cout << msg << endl;
	delete [] msg;
	
	return 0;
}
