#include <iostream>
#include <new>
using namespace std;

struct delegate
{
	char * name;
	int age;
};

int main(int argc, char** argv)
{
	delegate* students[4];

	for(int x = 0; x < 4; ++x)
	{
		students[x] = new (nothrow) delegate;
		students[x]->name = new (nothrow) char[50];
	}
	strcpy(students[0]->name, "Fred Flintstone"); 
	strcpy(students[1]->name, "Wilma Flintstone"); 
	strcpy(students[2]->name, "Barney Rubble"); 
	strcpy(students[3]->name, "Betty Rubble"); 

	students[0]->age = 21;
	students[1]->age = 22;
	students[2]->age = 23;
	students[3]->age = 24;

	for(int x = 0; x < 4; ++x)
	{
		cout << "Student " << (x+1) << ": " << students[x]->name 
			<< " aged " << students[x]->age << endl;
	}

	for(int x = 0; x < 4; ++x)
	{
		delete [] students[x]->name;
		delete students[x];
	}
	
	return 0;
}
