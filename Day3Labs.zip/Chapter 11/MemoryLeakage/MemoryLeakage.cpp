#include <iostream>
using namespace std;

struct outer
{
	double* innermemory;
};

int main(int argc, char** argv)
{
	char c;
	outer* outermemory;
	
	cout << "Check memory beore any allocation\n";
	c = getchar();
	
	outermemory = new outer[100];
	for(int x = 0; x < 100;++x)
	{
		outermemory[x].innermemory = new double[1000];
	}
	
	cout << "Check memory after allocating approx 800,000 bytes\n";
	c = getchar();
	
	for(int x = 0; x < 100;++x)
	{
		delete [] outermemory[x].innermemory;
	}
	delete [] outermemory;
	
	cout << "Check memory after deallocating outermemory\n";
	c = getchar();
	
	return 0;
}


