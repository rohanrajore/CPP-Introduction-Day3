#include <iostream>
#include <new>
#include <string.h>
using namespace std;

int main(int argc, char**argv)
{
	int* iptr;
	iptr = new int;
	delete iptr;

	char* msg;
	try
	{
		msg = new char[255];
	}
	catch (std::bad_alloc ex)
	{
		// memory allocation error
	}
	strcpy(msg, "Hello world!");
	cout << msg << endl;
	delete [] msg;
	
	return 0;
}



