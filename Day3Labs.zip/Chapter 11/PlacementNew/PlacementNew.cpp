#include <iostream>
#include <new>
using namespace std;

enum colour {Black, White, Red, Yellow, Blue, Green, OtherColour};
enum bodystyle {Hatchback, Saloon, Cabriolet, Sports, OtherStyle};
enum fuel {Petrol, Diesel, Electric, Hybrid, Hydrogen, OtherFuel};

class Car
{
public:
	Car()
	{	// default constructor
		paint = colour::OtherColour;
		engineCC = 0;
		bodyType = bodystyle::OtherStyle;
		poweredBy = fuel::OtherFuel;
		mileage = 0;
	}
	Car(colour c, int es, bodystyle b, fuel f, int m)
	{	// overloaded constructor
		paint = c;
		engineCC = es;
		bodyType = b;
		poweredBy = f;
		mileage = m;
	}
	void SetMileage(long m)
	{
		mileage = m;
	}
	long GetMileage()const
	{
		return mileage;
	}
	void Display()const
	{
		cout << "Car colour: " << paint << " Engine size: "
			<< engineCC << "cc Body Style: " << bodyType
			<< " powered by: " << poweredBy << " Odometer: "
			<< mileage << endl;
	}
private:
	colour paint;
	int engineCC;
	bodystyle bodyType;
	fuel poweredBy;
	long mileage;
};

int main(int argc, char** argv)
{
	char* pool;
	Car* carptr;

	pool = new char[sizeof(Car) *5];	// pre-allocate memory

	carptr = (Car*)pool;
	for (int x = 0; x < 5;++x)  
	{
		// initialize the car pool. Note the use of placement new
		new (carptr+x) Car(colour::Green, 1000+(x * 1000), bodystyle::Hatchback, 
						fuel::Diesel, 0);
	}
	// use a few cars
	carptr = (Car*)pool;

	(carptr + 2)->SetMileage(135790);
	(carptr + 4)->SetMileage(123456);

	// we replace cars after 100K miles
	carptr = (Car*)pool;
	for (int x = 0; x < 5; ++x)
	{
		if ((carptr + x)->GetMileage() > 100000)
		{
			cout << "Replacing ";
			(carptr + x)->Display();
			// re-initialize the car. Note the use of placement new
			new ((carptr + x)) Car(colour::Red, 1000 + (x * 1000), 
					bodystyle::Hatchback, fuel::Diesel, 0);
		}
	}

	delete[] pool;
	
	return 0;
}


