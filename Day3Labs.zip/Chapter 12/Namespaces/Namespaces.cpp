#include <iostream>
using namespace std;

namespace one
{
	int x = 10;
	double y = 99.99;
}

namespace two
{
	double x = 66.6;
	int y = 99;
}

namespace one
{
	char z = '*';
}

int main(int argc, char** argv)
{
	int x = 77;
	cout << "Local x: " << x << endl;

	one::x = 88;
	cout << "one::x: " << one::x << endl;



	one::y = 666.66;
	cout << "one::y: " << one::y << endl;

	one::z = 'z';
	cout << "one::z: " << one::z << endl;
	two::x = 99.99;
	cout << "two::x: " << two::x << endl;

	two::y = 0;
	cout << "two::y: " << two::y << endl;
	
	return 0;
}
