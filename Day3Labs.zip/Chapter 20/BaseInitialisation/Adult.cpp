#include "Adult.h"

Adult::Adult(void)
{
	smokes = false;
}

Adult::	Adult(int a, double h, bool s)
: Person(a,h)
{
	smokes = s;
}

Adult::~Adult(void)
{
}

void Adult::set_smoker(bool s)
{
	smokes = s;
}

bool Adult::is_smoker()
{
	return smokes;
}