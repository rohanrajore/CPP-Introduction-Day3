#include <iostream>
#include "Person.h"
#include "Adult.h"
#include "Child.h"
using namespace std;

int main(int argc, char** argv)
{
	Adult trainer;
	Child kid;

	trainer.set_age(21);
	trainer.set_height(6.0);
	trainer.set_smoker(false);
	kid.set_age(10);
	kid.set_height(4.2);
	kid.set_sex('M');

	cout << "Trainer age: " << trainer.get_age() << endl;
	cout << "Trainer height: " << trainer.get_height() << endl;
	cout << "Trainer smoker: " << trainer.is_smoker() << endl;
	cout << "Kid age: " << kid.get_age() << endl;
	cout << "Kid height: " << kid.get_height() << endl;
	cout << "Kid sex: " << kid.get_sex() << endl;
	
	return 0;
}
