#include <iostream>
#include "Person.h"
#include "Adult.h"
#include "Child.h"
using namespace std;

int main(int argc, char** argv)
{
	Adult trainer(21,6.0,false);
	
	trainer.Display();
	trainer.Person::Display();
	
	return 0;
}
