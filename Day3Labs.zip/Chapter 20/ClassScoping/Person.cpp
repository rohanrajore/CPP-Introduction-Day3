#include "Person.h"
#include <iostream>
using namespace std;

void Person::Display()const
{
	cout << "Age: " << age << " Height: "
		 << height << endl;
}

Person::Person(void)
{
	age = 0;
	height = 0;
}

Person::Person(int a, double h)
{
	age = a;
	height = h;
}

Person::~Person(void)
{
}

void Person::set_age(int a)
{
	age = a;
	height = 0;
}

void Person::set_height(double h)
{
	height = h;
}

int Person::get_age()
{
	return age;
}

double Person::get_height()
{
	return height;
}