#include "Boss.h"
#include <iostream>
using namespace std;

Boss::Boss(void)
{
	bonus = 0;
	cout << "Boss default constructor\n";
}

Boss::~Boss(void)
{
	cout << "Boss destructor\n";
}

Boss::Boss(const char* n, int a, char s, double b)
: Person(n,a,s)
{
	bonus = b;
	cout << "Boss overloaded constructor\n";
}

void Boss::Display()const
{
	Person::Display();
	cout << "Bonus = " << bonus << endl; 
}
