#pragma once
#include "Person.h"

class Boss :
	public Person
{
public:
	Boss(void);
	~Boss(void);
	Boss(const char* n, int a, char s, double b);
	void Display()const;
private:
	double bonus;
};
