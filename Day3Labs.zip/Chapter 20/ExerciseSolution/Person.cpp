#include "Person.h"
#include <iostream>
#include <cstring>
using namespace std;

int Person::numpeople;

Person::Person(void)
{
	name = new char[10];
	strcpy(name, "Anonymous");
	age = 0;
	sex = '?';
	++numpeople;
	cout << "Person default constructor\n";
}

Person::Person(const char* n, int a, char s)
{
	name = new char[strlen(n) + 1];
	strcpy(name, n);
	age = a;
	sex = s;
	++numpeople;
	cout << "Person overloaded constructor\n";
}

Person::~Person(void)
{
	delete [] name;
	--numpeople;
	cout << "Person destructor\n";
}

void Person::Display()const
{
	cout << "Person " << name << " is a "
		 << age << " year old " << sex << endl;
}

int Person::GetNumPeople()
{
	return numpeople;
}
