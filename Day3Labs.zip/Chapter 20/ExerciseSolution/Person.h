#pragma once

class Person
{
public:
	Person(void);
	Person(const char* name, int age, char sex);
	~Person(void);
	void Display()const;
	static int GetNumPeople();
private:
	char* name;
	int age;
	char sex;
	static int numpeople;
};
