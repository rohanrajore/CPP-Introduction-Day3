#include "Worker.h"
#include <iostream>
using namespace std;

Worker::Worker(void)
{
	rate = 0.0f;
	hours = 0;
	cout << "Worker default constructor\n";
}

Worker::~Worker(void)
{
	cout << "Worker destructor\n";
}

Worker::Worker(const char* n, int a, char s, float r, int h)
: Person(n,a,s)
{
	rate = r;
	hours = h;
	cout << "Worker overloaded constructor\n";
}

void Worker::Display()const
{
	Person::Display();
	cout << "Hours = " << hours << " at rate " 
		 << rate << " per hour\n";
}
