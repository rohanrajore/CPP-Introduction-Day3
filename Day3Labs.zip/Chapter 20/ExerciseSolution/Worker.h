#pragma once
#include "Person.h"

class Worker : 	public Person
{
public:
	Worker(void);
	~Worker(void);
	Worker(const char* n, int a, char s, float r, int h);
	void Display()const;
private:
	float rate;
	int hours;
};
