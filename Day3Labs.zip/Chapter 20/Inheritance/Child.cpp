#include "Child.h"

Child::Child(void)
{
	sex = '?';
}

Child::~Child(void)
{
}

void Child::set_sex(char s)
{
	sex = s;
}

char Child::get_sex()
{
	return sex;
}



