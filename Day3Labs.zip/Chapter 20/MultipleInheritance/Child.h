#include "Parents.h"
#include <cstring>
using namespace std;

class Child : public Father, public Mother
{
public:
	void set_child(const char* kid)
	{
		childs_name = new char[255];
		strcpy(childs_name,kid);
	}
	char* get_child(){return childs_name;}
private:
	char* childs_name;
};


