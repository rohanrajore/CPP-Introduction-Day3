#include "Child.h"
#include <iostream>
using namespace std;

int main(int argc, char** argv)
{
	Child mykid;
	mykid.set_dad("Simon");
	mykid.set_mum("Lyn");
	mykid.set_child("Christopher");
	
	return 0;
}
