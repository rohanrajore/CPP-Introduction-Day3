#include <cstring>
using namespace std;

class Father
{
public:
	void set_dad(const char* dad)
	{
		dads_name = new char[255];
		strcpy(dads_name,dad);
	}
	char* get_dad(){return dads_name;}
private:
	char* dads_name;
};

class Mother
{
public:
	void set_mum(const char* mum)
	{
		mums_name = new char[255];
		strcpy(mums_name,mum);
	}
	char* get_mum(){return mums_name;}
private:
	char* mums_name;
};



