#include <iostream>
#include "Person.h"
#include "Boss.h"
#include "Worker.h"
using namespace std;

int main(int argc, char** argv)
{
	Person* people[5];

	people[0] = new Person("Fred", 21,'M');
	people[1] = new Boss("Simon", 50,'M',1000000.99);
	people[2] = new Worker("Jack", 23,'M',5.80f,45);
	people[3] = new Worker("Jill", 22,'F',6.00f,40);
	people[4] = new Person("Freda", 19,'f');

	for(int x = 0; x < 5; ++x)
	{
		people[x]->Display();
	}

	for(int x = 0; x < 5; ++x)
	{
		delete people[x];
	}
}
