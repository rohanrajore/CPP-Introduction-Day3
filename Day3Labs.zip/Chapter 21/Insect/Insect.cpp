#include "Insect.h"

int main(int argc, char** argv)
{
	Ant crawler;
	Butterfly flapper;
	Insect* iptr;

	iptr = & crawler;
	iptr->move();		// ant move
	iptr = & flapper;
	iptr->move();		// butterfly move
	
	return 0;
}
