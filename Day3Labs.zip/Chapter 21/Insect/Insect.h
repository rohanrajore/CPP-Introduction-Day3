#include <iostream>
using namespace std;

class Insect
{
public:
	virtual void move() const
	{cout << "Generic move\n";}
};

class Ant : public Insect
{
public:
	void move() const
	{cout << "crawl crawl\n";}
};

class Butterfly : public Insect
{
public:
	void move() const
	{cout << "flap flap\n";}
};


