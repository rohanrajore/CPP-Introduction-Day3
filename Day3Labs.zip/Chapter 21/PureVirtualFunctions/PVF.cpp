#include "Tree.h"

int main(int argc, char** argv)
{
	Tree* pGeneric;
	pGeneric = new AppleTree();
	pGeneric->Grow();
	pGeneric->ShedLeaves();
	pGeneric = new OakTree();
	pGeneric->Grow();
	pGeneric->ShedLeaves();
	pGeneric = new ConkerTree();
	pGeneric->Grow();
	pGeneric->ShedLeaves();
	
	return 0;
}
