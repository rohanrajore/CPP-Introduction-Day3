class Tree
{
public:
	virtual void Grow() = 0;

	virtual void ShedLeaves()
	{
		// shed leaves in autumn, shed and set seeds
	}
};

class OakTree : public Tree
{
	virtual void Grow()
	{
		// grow 15cm / year
	}
};

class ConkerTree : public Tree
{
	virtual void Grow()
	{
		// grow 10cm / year
	}
};

class AppleTree : public Tree
{
	virtual void Grow()
	{
		// grow 30cm / year
	}
	virtual void ShedLeaves()
	{
		// shed leaves in autumn, no fruit to shed this will have been harvested
	}
};


