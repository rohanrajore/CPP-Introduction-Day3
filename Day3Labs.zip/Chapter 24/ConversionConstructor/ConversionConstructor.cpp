#include <iostream>
#include "Person.h"
#include "Employee.h"

using namespace std;

int main()
{
	Employee me("Fred",21,'M',111111);
	Person you(me);
	
	me.Display();
	you.Display();
	
	return 0;
}


