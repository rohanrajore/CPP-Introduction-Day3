#include "Employee.h"
#include <cstring>
#include <iostream>
using namespace std;
Employee::Employee(void)
{
	name = new char[10];
	strcpy(name,"Anonymous");
	age = 0;
	sex = '?';
	empid = 999;
}
Employee::Employee(const char* n, int a, char s, long eid)
{
	name = new char[strlen(n) + 1];
	strcpy(name, n);
	age = a;
	sex = s;
	empid = eid;
}
Employee::~Employee()
{
	delete [] name;
}
char* Employee::GetName() const
{
	return name;
}
int Employee::GetAge() const
{
	return age;
}
char Employee::GetSex() const
{
	return sex;
}
void Employee::Display()const
{
	cout << "Employee " << name << " and employee ID " << empid 
		<< " is a " << age << " year old " << sex << endl;
}



