#pragma once

class Employee
{
public:
	Employee();
	Employee(const char* n, int a, char s, long eid);
	~Employee();
	char* GetName() const;
	int GetAge() const;
	char GetSex() const;
	void Display()const;
private:
	char* name;
	int age;
	char sex;
	long empid;
};


