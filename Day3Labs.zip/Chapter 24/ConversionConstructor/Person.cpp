#include "Person.h"
#include <iostream>
using namespace std;

Person::Person(void)
{
	name = new char[10];
	strcpy(name,"Anonymous");
	age = 0;
	gender = '?';
	cout << "Person default constructor\n";
}
Person::Person(const char* n, int a, char g)
{
	name = new char[strlen(n) + 1];
	strcpy(name, n);
	age = a;
	gender = g;
	cout << "Person overloaded constructor\n";
}
Person::Person(const Person& p)
{
	name = new char[strlen(p.name) + 1];
	strcpy(name, p.name);
	age = p.age;
	gender = p.gender;
	cout << "Person copy constructor\n";
}
Person::Person(const Employee& e)
{
	name = new char[strlen(e.GetName()) + 1];
	strcpy(name, e.GetName());
	age = e.GetAge();
	gender = e.GetSex();
	cout << "Person constructed from Employee\n";
}
Person::~Person()
{
	delete [] name;
	cout << "Person destructor\n";
}
void Person::Display()const
{
	cout << "Person " << name << " is a "
		 << age << " year old " << gender << endl;
}
char* Person::GetName() const
{
	return name;
}
int Person::GetAge() const
{
	return age;
}

char Person::GetGender() const
{
	return gender;
}

