#include <iostream>
#include "Person.h"

using namespace std;

int main()
{
	
	Person me("Simon",21,'M');
	Person you(me);

	me.Display();
	you.Display();
	
	return 0;
}


