#pragma once
#include <iostream> 
#include <cstring>
using namespace std;

class Person
{
public:
	Person(void);
	Person(const char* name, int age, char gender);
	Person(const Person& p);
	char* GetName() const;
	int GetAge() const;
	char GetGender() const;
	~Person(void);
	void Display()const;
private:
	char* name;
	int age;
	char gender;
};

