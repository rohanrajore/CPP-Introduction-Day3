#include <iostream>
#include "Person.h"
#include "Boss.h"
#include "Worker.h"
using namespace std;

int main()
{
	Person him("Fred Flintstone", 44, 'M');
	Person man(him);
	Person male;
	male = him;
	

	if (him == man)
	{
		cout << "him = man" << endl;
	}
	
	return 0;
}
