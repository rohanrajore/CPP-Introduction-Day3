#pragma once

class Person
{
public:
	Person(void);
	Person(const char* name, int age, char gender);
	Person(const Person& p);
	virtual ~Person(void);
	Person& operator=(const Person& rhs);
	bool operator==(const Person& rhs);
	virtual void Display()const;
	static int GetNumPeople();
private:
	char* name;
	int age;
	char gender;
	static int numpeople;
};
