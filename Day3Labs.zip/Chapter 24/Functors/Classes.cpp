#include <iostream>
#include "Classes.h"
using namespace std;


int Add1::operator() (int a, int b) 
{
   return a + b;
}

int Add2::operator() (int a)
{
   return storedNumber + a;
}

bool Compare::operator()(int a, int b)
{
	return (a == b);
}

int All3::operator() (int a, int b) 
{
   return a + b;
}

int All3::operator() (int a)
{
   return storedNumber + a;
}

//bool All3::operator()(int a, int b)
//{
//	return (a == b);
//}

