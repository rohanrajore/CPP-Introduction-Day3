#pragma once
#include <iostream>
using namespace std;

class Add1
{
public:
    // overload function call operator accept two integer arguments
    // return their sum
    int operator() (int a, int b); 
};

class Add2
{
private:
	int storedNumber;
public:
	Add2(int n) : storedNumber(n) {}	// Overloaded Constructor
    // overload function call operator add argument to stored state 
    int operator() (int a); 
};

class Compare
{
public:
	bool operator()(int a, int b);
};

class All3
{
private:
	int storedNumber;
public:
	All3(int n) : storedNumber(n) {}	// Overloaded Constructor
	int operator() (int a, int b); 
	int operator() (int a);
//	bool operator()(int a, int b);	Invalid overload - clashes with the first one!
};
