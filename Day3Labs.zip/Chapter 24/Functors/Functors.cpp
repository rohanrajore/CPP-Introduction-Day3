#include <iostream>
#include "Classes.h"
using namespace std;

int main()
{
	Add1 a1;
	
	int total = a1(15,21);
	cout << total << endl;
	
	Add2 a2(21);
	cout << a2(10) << endl;
	cout << a2(15) << endl;
	
	Compare c;
	
	cout << boolalpha << c(10, 10) << endl;
	cout << boolalpha << c(10, 20) << endl;
	
	All3 a3(666);
	cout << a3(10, 20) << endl;
	cout << a3(111) << endl;
	//cout << boolalpha << a3(666, 666) << endl;
	//cout << boolalpha << a3(666, 667) << endl;
	
	return 0;
}



