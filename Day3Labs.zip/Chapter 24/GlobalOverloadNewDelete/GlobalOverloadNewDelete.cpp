#include<iostream>
#include<stdlib.h>
 
using namespace std;
void * operator new(size_t size)
{
    cout << "New operator overloading " << endl;
    void * p = malloc(size);
    return p;
}
 
void * operator new[](size_t size)
{
    cout << "New [] operator overloading " << endl;
    void * p = malloc(size);
    return p;
}

void operator delete(void * p)
{
    cout << "Delete operator overloading " << endl;
    free(p);
}

void operator delete[](void * p)
{
    cout << "Delete [] operator overloading " << endl;
    free(p);
}

class MyClass
{
public:
	MyClass() { cout << "Constructing MyClass\n"; }
	~MyClass() { cout << "Destructing MyClass\n"; }
	void SetVal(int x) { number = x; }
	void Display() { cout << number << " Using MyClass\n"; }
private:
	int number;
};

int main()
{
	int* px = new int;
	*px = 666;
	cout << "*px = " << *px << endl;
	delete px;
	
    int * p = new int[3];
    for (int i = 0; i<3; ++i)
    {
    	p[i]= i;
    }
    cout << "Array: ";
    for(int i = 0; i<3; ++i)
    {
        cout << p[i] << " ";
    }   
    cout << endl;
    delete [] p;
    
    MyClass* pm = new MyClass;
    pm->SetVal(666);
    pm->Display();
    delete pm;
    
    MyClass* arrpm = new MyClass[3];
    for(int i = 0; i<3; ++i)
    {
        arrpm[i].SetVal(i);
    }   
    cout << "Array: ";
    for(int i = 0; i<3; ++i)
    {
        arrpm[i].Display();
    }   
    delete [] arrpm;
}
