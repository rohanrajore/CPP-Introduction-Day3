#include <iostream>
#include <cstring>
#include "Copy.h"
using namespace std;

Copy::Copy()				// default constructor
{
	largeMemBlock = new int[1000000];
	memBlockSize = 1000000;
}
Copy::~Copy()			// destructor
{
	if (largeMemBlock != nullptr)
	{
		// cout << "Deallocating largeMemBlock" << endl;
		delete[] largeMemBlock;
	}
}
Copy::Copy(const Copy& clone)	// copy constructor
{
	cout << "Copy constructor called - Copying largeMemBlock" << endl;
	largeMemBlock = new int[clone.memBlockSize];
	memcpy(largeMemBlock, clone.largeMemBlock, clone.memBlockSize * 4);
	memBlockSize = clone.memBlockSize;
}
Copy::Copy(Copy&& clone)	// move constructor
{
	cout << "Move constructor called - Moving largeMemBlock" << endl;
	largeMemBlock = clone.largeMemBlock;
	clone.largeMemBlock = nullptr;
	memBlockSize = clone.memBlockSize;
}
Copy& Copy::operator=(const Copy& rhs)	// Assignment operator
{
	delete[] largeMemBlock;
	cout << "Copy assignment operaotor called" << endl;
	largeMemBlock = new int[rhs.memBlockSize];
	memcpy(largeMemBlock, rhs.largeMemBlock, rhs.memBlockSize * 4);
	memBlockSize = rhs.memBlockSize;
	return *this;
}
Copy& Copy::operator=(Copy&& rhs)	// Move Assignment operator
{
	delete[] largeMemBlock;
	cout << "Move assignment operaotor called" << endl;
	largeMemBlock = rhs.largeMemBlock;
	memBlockSize = rhs.memBlockSize;
	rhs.largeMemBlock = nullptr;
	rhs.memBlockSize = 0;
	return *this;
}


