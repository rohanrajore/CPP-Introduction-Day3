#pragma once

class Copy
{
public:
	Copy();								// default constructor
	~Copy();							// destructor
	Copy(const Copy& clone);			// copy constructor
	Copy(Copy&& clone);					// move constructor
	Copy& operator=(const Copy& rhs);	// Assignment operator
	Copy& operator=(Copy&& rhs);		// Move Assignment operator
private:
	int* largeMemBlock;
	int memBlockSize;
};



