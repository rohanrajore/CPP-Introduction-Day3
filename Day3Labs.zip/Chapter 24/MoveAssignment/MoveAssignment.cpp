#include "Copy.h"

int main()
{
	Copy one;
	Copy two;

	two = one;
	two = Copy();
	
	return 0;	
}
