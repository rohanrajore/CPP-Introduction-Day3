#include "Copy.h"
#include <iostream>
#include <cstring>
using namespace std;

Copy::Copy()				// default constructor
{
	largeMemBlock = new int[1000000];
	memBlockSize = 1000000;
}
Copy::~Copy()				// destructor
{
	if (largeMemBlock != nullptr)
	{
		delete[] largeMemBlock;
	}
}
Copy::Copy(const Copy& clone)	// copy constructor
{
	cout << "Copy constructor called - Copying largeMemBlock" << endl;
	largeMemBlock = new int[clone.memBlockSize];
	memcpy(largeMemBlock, clone.largeMemBlock, clone.memBlockSize * 4);
	memBlockSize = clone.memBlockSize;
}
Copy::Copy(Copy&& clone)		// move constructor
{
	cout << "Move constructor called - Moving largeMemBlock" << endl;
	largeMemBlock = clone.largeMemBlock;
	clone.largeMemBlock = nullptr;
	memBlockSize = clone.memBlockSize;
}

