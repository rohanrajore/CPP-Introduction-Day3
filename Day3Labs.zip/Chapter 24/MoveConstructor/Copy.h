#pragma once
class Copy
{
public:
	Copy();					// default constructor
	~Copy();				// destructor
	Copy(const Copy& clone);// copy constructor
	Copy(Copy&& clone);		// move constructor
private:
	int* largeMemBlock;
	int memBlockSize;
};



