#include <vector>
#include <queue>
#include <list>
#include "Copy.h"
using namespace std;

void Doit1(Copy c)		// copy (by value) parameter
{

}
Copy Doit2()
{
	Copy x;
	return x;			// copy return
}
int main()
{
	Copy one;			// default constructor
	Copy two(one);		// copy construction
	Copy three = one;	// copy construction by assignment

	Doit1(one);			// copy parameter
	Doit2();			// copy return uses move constructor

	vector<Copy> v;
	v.push_back({});

	queue<Copy> q;
	q.push({});

	list<Copy> l;
	l.push_back({});
	
	return 0;
}



