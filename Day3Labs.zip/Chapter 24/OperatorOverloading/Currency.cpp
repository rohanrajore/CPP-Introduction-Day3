#include "Currency.h"
#include <iostream>
using namespace std;

Currency::Currency()
{
	pounds = 0;
	pence = 0;
}
Currency::Currency(int pounds, int pence)
{
	this->pounds = pounds;
	this->pence = pence;
}
double Currency::GetCurrency() const
{
	return pounds + (pence/100.0);
}
void Currency::SetPounds(int pounds)
{
	this->pounds = pounds;
}
void Currency::SetPence(int pence)
{
	this->pence = pence;
}
int Currency::GetPounds() const
{
	return pounds;
}
int Currency::GetPence() const
{
	return pence;
}
Currency Currency::operator+(const Currency& rhs)
{
	Currency temp;
	temp.pounds = this->pounds + rhs.pounds;
	temp.pence = this->pence + rhs.pence;
	if (temp.pence >= 100)
	{
		++temp.pounds;
		temp.pence -= 100;
	}
	return temp;
}
Currency Currency::operator++(int postfix)		// postfix has dummy argument
{
	Currency temp(*this);
	++this->pounds;
	return temp;
}
Currency& Currency::operator++()				// prefix
{
	++this->pounds;
	return *this;
}
bool Currency::operator==(const Currency& rhs)
{
	return ((this->pounds == rhs.pounds) && (this->pence == rhs.pence));
}
bool Currency::operator<(const Currency& rhs)
{
	return ((this->pounds < rhs.pounds)||
			((this->pounds == rhs.pounds) && (this->pence < rhs.pence)));
}
ostream& operator<<(ostream& stream, const Currency& c)
{
	stream << "£" << c.pounds << "." <<  c.pence;
	return stream;
}
istream& operator>>(istream& stream, Currency& c)
{
	stream >>  c.pounds >>  c.pence;
	return stream;
}

