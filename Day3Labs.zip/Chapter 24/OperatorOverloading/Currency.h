#pragma once
#include <iostream>
using namespace std;

class Currency
{
public:
	Currency();
	Currency(int pounds, int pence);
	double GetCurrency() const;
	void SetPounds(int pounds);
	void SetPence(int pence);
	int GetPounds()const;
	int GetPence() const;
	Currency operator+(const Currency& rhs);
	Currency operator++(int postfix);	// postfix has dummy argument
	Currency& operator++();				// prefix
	bool operator==(const Currency& rhs);
	bool operator<(const Currency& rhs);
	friend ostream& operator<<(ostream& stream, const Currency& c);
	friend istream& operator>>(istream& stream, Currency& c);
private:
	int pounds;
	int pence;
};

	
