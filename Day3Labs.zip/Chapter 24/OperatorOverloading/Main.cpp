#include "Currency.h"
#include <iostream>
using namespace std;

int main()
{
	Currency cash(9, 99);
	Currency dosh;
	
	cout << cash << endl;
	
	cin >> dosh;
	cout << dosh << endl;
	
	
	
	return 0;
}


