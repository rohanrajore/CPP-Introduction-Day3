#include <iostream>
#include "SafeArray.h"
using namespace std;


SafeArray::SafeArray()
{
	unsafe = new int[10];
	ncol = 10;
}
SafeArray::SafeArray(int size)
{
	unsafe = new int[size];
	ncol = size;
}
int& SafeArray::operator[](int column)
{
	if (column < ncol)
	{
		return unsafe[column];
	}
	else
	{
		throw "Subscript error";
	}
}



