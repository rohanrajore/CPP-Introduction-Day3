#pragma once
#include <iostream>
using namespace std;

class SafeArray
{
public:
	SafeArray();
	SafeArray(int size);
	int& operator[](int column);
private:
	int* unsafe;
	int ncol;
};


