#include <iostream>
#include "SafeArray.h"
using namespace std;

int main()
{
	SafeArray nums(20);
	nums[10] = 10;
	cout << nums[10] << endl;
	try
	{
		nums[21] = 99;
	}
	catch(const char* m)
	{
		cout << m << endl;
	}
	
	return 0;
}



