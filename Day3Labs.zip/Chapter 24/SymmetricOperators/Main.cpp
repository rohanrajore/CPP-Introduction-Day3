#include "Currency.h"
#include <iostream>
using namespace std;

int main()
{
	Currency cash(9, 99);
	Currency dosh;
	
	dosh = cash + 250;
	cout << dosh << endl;
	
	dosh = 250 + cash;
	cout << dosh << endl;
	
	
	return 0;
}


