#include "ValRef.h"
#include <iostream>
using namespace std;

int main()
{
	Currency sterling("GB£", 1000.99);

	Currency another("GB£", 2000.99);

	sterling.Display();
	another.Display();

	another = sterling;

	sterling.Display();
	another.Display();

	return 0;
}


