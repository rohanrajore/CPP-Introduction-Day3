#include "ValRef.h"
#include <iostream>
#include <cstring>
using namespace std;

Currency& Currency::operator=(const Currency& rhs)
{
	delete[] currencyName;
	currencyName = new char[strlen(rhs.currencyName) + 1];
	strcpy(currencyName, rhs.currencyName);
	amount = rhs.amount;
	return *this;
}

Currency::Currency(const Currency& copyFrom)
{
	currencyName = new char[strlen(copyFrom.currencyName) + 1];
	strcpy(currencyName, copyFrom.currencyName);
	amount = copyFrom.amount;
}

Currency::Currency(const char* name, const double amnt)
{
	currencyName = new char[strlen(name) + 1];
	strcpy(currencyName, name);
	amount = amnt;
}

void Currency::Display()const
{
	cout << currencyName << " " << amount << endl;
}

Currency::~Currency()
{
	delete[] currencyName;
}
