#pragma once

class Currency
{
public:
    Currency& operator=(const Currency&);
    Currency(const Currency&);
    Currency(const char* name, const double amnt);
    void Display()const;
    ~Currency();
private:
    char* currencyName;
    double amount;
};

class MyRefType 
{
private:
    MyRefType& operator=(const MyRefType&) = delete;
    MyRefType(const MyRefType&) = delete;
public:
    MyRefType() {}
    virtual ~MyRefType() {}
};

